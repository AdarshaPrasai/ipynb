#include <stdio.h>

int main() {
    int x;
      // Reads an integer input from the user
    printf("Integer: ");
    scanf("%d", &x);
    printf("%d",x);
}





